export class PipecatRuntime {
  async chat() {
    throw new Error("Pipecat runtime not configured")
  }
}
