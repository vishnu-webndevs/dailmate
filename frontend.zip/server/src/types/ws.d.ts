declare module "ws";

